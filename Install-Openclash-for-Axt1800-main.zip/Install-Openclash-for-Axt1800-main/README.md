wget -qO- https://cdn.jsdelivr.net/gh/m0eak/Install-Openclash-for-Axt1800/install.sh | sh -s passwall 

安装帕斯沃 


wget -qO- https://cdn.jsdelivr.net/gh/m0eak/Install-Openclash-for-Axt1800/install.sh | sh -s ssr-plus 

安装瘦身乳 


wget -qO- https://cdn.jsdelivr.net/gh/m0eak/Install-Openclash-for-Axt1800/install.sh | sh -s openclash 

安装猫猫 


wget -qO- https://cdn.jsdelivr.net/gh/m0eak/Install-Openclash-for-Axt1800/install.sh | sh 

全装 
 
